-printf "%d\n" 20

