printf "%d\n" 30
