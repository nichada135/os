salutation="Hello"
echo $salutation
echo "The program $0 is now running"
echo "The first parameter is $1"
echo "The second parameter is $2"
echo "The parameter list is $*"
echo "The user's home folder is $HOME"
exit 0
